import { test, expect, errors } from '@playwright/test';
import { PropertyRegsiterApi } from '../../propertyRegisterApi';
import { LastWillSearchRelatedRequestModel } from '../../requestModels/lastWillSearchRelatedRequestModel';
import StringFunctions from '../../functions/string_functions';

test.describe('LastWillSearchRelated API tests', () => {
  const propertyRegisterApi = new PropertyRegsiterApi();
  const stringFunctions = new StringFunctions();
  const simbols = 90;

  const lastWillSearchRelatedRequestfirstNameMoreSimbols: LastWillSearchRelatedRequestModel = {
    searchOption: "0",
    egn: "8508010133",
    firstName: stringFunctions.makeString(simbols),
    middleName: stringFunctions.makeString(10),
    lastName: stringFunctions.makeString(10),
    secondLastName: stringFunctions.makeString(10)
  };

  const lastWillSearchRelatedRequestmiddleNameMoreSimbols: LastWillSearchRelatedRequestModel = {
    searchOption: "0",
    egn: "8508010133",
    firstName: stringFunctions.makeString(10),
    middleName: stringFunctions.makeString(simbols),
    lastName: stringFunctions.makeString(10),
    secondLastName: stringFunctions.makeString(10)
  };

  const lastWillSerachRelatedRequestlastNameMoreSimbols: LastWillSearchRelatedRequestModel = {
    searchOption: "0",
    egn: "8508010133",
    firstName: stringFunctions.makeString(10),
    middleName: stringFunctions.makeString(10),
    lastName: stringFunctions.makeString(simbols),
    secondLastName: stringFunctions.makeString(10)
  };

  const lastWillSearchRelatedRequestsecondlastNameMoreSimbols: LastWillSearchRelatedRequestModel = {
    searchOption: "0",
    egn: "8508010133",
    firstName: stringFunctions.makeString(10),
    middleName: stringFunctions.makeString(10),
    lastName: stringFunctions.makeString(10),
    secondLastName: stringFunctions.makeString(simbols)
  };

  const testCases = [
    { lastWillSearchRequestModel: lastWillSearchRelatedRequestfirstNameMoreSimbols, expectedCode: 200, },
    { lastWillSearchRequestModel: lastWillSearchRelatedRequestmiddleNameMoreSimbols, expectedCode: 200 },
    { lastWillSearchRequestModel: lastWillSerachRelatedRequestlastNameMoreSimbols, expectedCode: 200 },
    { lastWillSearchRequestModel: lastWillSearchRelatedRequestsecondlastNameMoreSimbols, expectedCode: 200 },
  ];

  let testNumber = 0;
  for (const singleTestCase of testCases) {
    testNumber += 1;

    test(`Сценарий ${testNumber} с превишен брой символи в имената, expectedCode: ${singleTestCase.expectedCode}`, async ({ request }) => {

      // Act: изпълняваме POST заявка към API-то
      const response = await propertyRegisterApi.lastWillSearchRelatedPOST(singleTestCase.lastWillSearchRequestModel, request)

      //Assert: проверяваме очаквания резултат
      expect(response.status()).toBe(singleTestCase.expectedCode);

      const responseAsJson = await response.json();
      expect(responseAsJson['errors'][0]['error']).toEqual('Максималният брой символи е 35');
      expect(responseAsJson['isSuccess']).toBe(false);
    });
  }

  test('200 с грешка при подадено празно notaryActNumber', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedEmptynotaryActNumber: LastWillSearchRelatedRequestModel = {
      lastWillId: "10004500100000004822",
      searchOption: "3",
      personTypeId: "10000500000000000021",
      areaId: "10000900000000015838",
      applicantId: "10003200100001001776",
      notaryActNumber: "",
      notaryActVolume: "22",
      notaryActRegisterNumber: "22",
      notaryActLawsuitYear: "2023"
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedEmptynotaryActNumber, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за номер на нотариален акт е задължително.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено празно notaryActVolume', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedEmptynotaryActVolume: LastWillSearchRelatedRequestModel = {
      lastWillId: "10004500100000004822",
      searchOption: "3",
      personTypeId: "10000500000000000021",
      areaId: "10000900000000015838",
      applicantId: "10003200100001001776",
      notaryActNumber: "22",
      notaryActVolume: "",
      notaryActRegisterNumber: "22",
      notaryActLawsuitYear: "2023"
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedEmptynotaryActVolume, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за том на нотариален акт е задължително.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено празно notaryActRegisterNumber', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedEmptynotaryActRegisterNumber: LastWillSearchRelatedRequestModel = {
      lastWillId: "10004500100000004822",
      searchOption: "3",
      personTypeId: "10000500000000000021",
      areaId: "10000900000000015838",
      applicantId: "10003200100001001776",
      notaryActNumber: "22",
      notaryActVolume: "22",
      notaryActRegisterNumber: "",
      notaryActLawsuitYear: "2023"
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedEmptynotaryActRegisterNumber, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за номер на регистър на нотариален акт е задължително.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено празно notaryActLawsuitYear', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedEmptynotaryActLawsuitYear: LastWillSearchRelatedRequestModel = {
      lastWillId: "10004500100000004822",
      searchOption: "3",
      personTypeId: "10000500000000000021",
      areaId: "10000900000000015838",
      applicantId: "10003200100001001776",
      notaryActNumber: "22",
      notaryActVolume: "22",
      notaryActRegisterNumber: "22",
      notaryActLawsuitYear: ""
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedEmptynotaryActLawsuitYear, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за година на дело за нотариален акт е задължително.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено невалидно notaryActLawsuitYear', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedInvalidnotaryActLawsuitYear: LastWillSearchRelatedRequestModel = {
      lastWillId: "10004500100000004822",
      searchOption: "3",
      personTypeId: "10000500000000000021",
      areaId: "10000900000000015838",
      applicantId: "10003200100001001776",
      notaryActNumber: "22",
      notaryActVolume: "22",
      notaryActRegisterNumber: "22",
      notaryActLawsuitYear: "test"
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedInvalidnotaryActLawsuitYear, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за година на дело за нотариален акт е невалидно.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено непопълнено proceedingsCourtId', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedEmptyproceedingsCourtId: LastWillSearchRelatedRequestModel = {
      lastWillId: "",
      searchOption: "4",
      proceedingsCourtId: "",
      proceedingsYear: "2023"
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedEmptyproceedingsCourtId, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за съд е задължително.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено непопълнено proceedingsYear', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedEmptyproceedingsYear: LastWillSearchRelatedRequestModel = {
      lastWillId: "",
      searchOption: "4",
      proceedingsCourtId: "10000900000000015821",
      proceedingsYear: ""
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedEmptyproceedingsYear, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за година на съдебно дело е задължително.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });

  test('200 с грешка при подадено невалидно proceedingsYear', async ({ request }) => {
    //Arrange: подготвяме данни с невалидна операция
    const lastWillWillSearchRelatedInvalidproceedingsYear: LastWillSearchRelatedRequestModel = {
      lastWillId: "",
      searchOption: "4",
      proceedingsCourtId: "10000900000000015821",
      proceedingsYear: "тест"
    }

    // Act: изпълняваме POST заявка към API-то
    const response = await propertyRegisterApi.lastWillSearchRelatedPOST(lastWillWillSearchRelatedInvalidproceedingsYear, request);

    //Assert: проверяваме очаквания резултат
    expect(response.status()).toBe(200);

    const responseAsJson = await response.json();
    expect(responseAsJson['errors'][0]['error']).toEqual('Полето за година на съдебно дело е невалидно.');
    expect(responseAsJson['isSuccess']).toBe(false);
  });
});

