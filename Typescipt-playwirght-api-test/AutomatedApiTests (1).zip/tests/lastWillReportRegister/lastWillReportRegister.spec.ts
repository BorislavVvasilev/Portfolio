import { test, expect } from '@playwright/test';
import { PropertyRegsiterApi } from '../../propertyRegisterApi'
import { LastWillReportRegisterModel } from '../../requestModels/lastWillReportRegisterModel';

test.describe('Last Will Report Register API test', () => {
    const propertyRegisterApi = new PropertyRegsiterApi();
    const operations = ['get', 'put', 'delete', 'patch', 'head', 'update', 'save'];
    
   
    test('500 при невалидно invalid bookTypeId', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const lastWillReportRegisterModelInvalidBookTypeID: LastWillReportRegisterModel = {
            year: 2021,
            fromNumber: 1,
            toNumber: 10,
            fromDate: "2021-01-01",
            toDate: "2021-12-31",
            bookTypeId: "invalidBookTypeId", // невалиден bookTypeId
            statusId: "10000500000000000015",
            showSummary: true,
            siteNomId: "10000500000000000015",
            operation: "getparamkey",
            hasAccess: true,
            isSuccess: true,
            reportParameterKey: "10000500000000000015"
        }

        // Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.lastWillReportRegisterPOST(lastWillReportRegisterModelInvalidBookTypeID, request);

        // Assert: проверяване очаквания резултат
        expect(response.status()).toBe(500);
    });
    for (const operation of operations) {
        test(`200 с грешка при операция ${operation.toUpperCase()} operation`, async ({ request }) => {
            // Подготвяме данни с невалидна операция
            const lastWillReportRegisterModelWrongOperation: LastWillReportRegisterModel = {
                year: 2021,
                fromNumber: 1,
                toNumber: 10,
                fromDate: "2021-01-01",
                toDate: "2021-12-31",
                bookTypeId: "10001100000000019600", 
                statusId: "10000500000000000015",
                showSummary: true,
                siteNomId: "10000500000000000015",
                operation: operation, // невалидна операция
                hasAccess: true,
                isSuccess: true,
                reportParameterKey: "10000500000000000015"
            }

            // Act: изпълняване POST заявак към АПИ-то
            const response = await propertyRegisterApi.lastWillReportRegisterPOST(lastWillReportRegisterModelWrongOperation, request);

            // Assert: проверяване очаквания резултат
            expect(response.status()).toBe(200);

            const responseAsJson = await response.json();
            expect(responseAsJson['errors'][0]['error']).toEqual('Operation is wrong');
            expect(responseAsJson['isSuccess']).toBe(false);
        });
    }
    
});

