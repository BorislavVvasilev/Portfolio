import { test, expect } from '@playwright/test';
import { PersonDetailsRequestModel } from '../../requestModels/personDetailsRequestModel';
import { PropertyRegsiterApi } from '../../propertyRegisterApi';
import StringFunctions from '../../functions/string_functions';

test.describe('LastWillDetail API tests', () => {
    const propertyRegisterApi = new PropertyRegsiterApi();
    const stringFunctions = new StringFunctions();

    test('200 с грешка при невалидно егн', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personDetailsRequestModelInvalidEgn: PersonDetailsRequestModel = {
            operation: "save",
            processId: stringFunctions.uuid(),
            egn: "8945625263",
            firstName: "Петър",
            middleName: "Петров",
            lastName: "Петров",
            personTypeId: "10000500000000000015"
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personDetailsPOST(personDetailsRequestModelInvalidEgn, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Невалидно ЕГН.');
        expect(responseAsJson['isSuccess']).toBe(false);
    });

    test('500 с грешка при съществуващо лице', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personDetailsRequestModelExistingUser: PersonDetailsRequestModel = {
            operation: "saveAsNew",
            id: "10000900100000006690",
            processId: stringFunctions.uuid(),
            egn: "8508010133",
            personalLotNumber: "642903",
            firstName: "Иван",
            middleName: "Иванов",
            lastName: "Иванов",
            personTypeId: "10000500000000000015"
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personDetailsPOST(personDetailsRequestModelExistingUser, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(500);
    });

    test('200 с грешка при празно firstName', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personDetailsRequestModelEmptyfirstName: PersonDetailsRequestModel = {
            operation: "save",
            invalidEgn: "8508010133",
            processId: stringFunctions.uuid(),
            egn: "8508010133",
            firstName: "",
            lastName: "Иванов",
            personTypeId: "10000500000000000015",
            skipEgnValidation: false
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personDetailsPOST(personDetailsRequestModelEmptyfirstName, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Поле име е задължително.');
        expect(responseAsJson['isSuccess']).toBe(false);
    });

    test('200 с грешка при празно lastName', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personDetailsRequestModelEmptylastName: PersonDetailsRequestModel = {
            operation: "save",
            invalidEgn: "8508010133",
            processId: stringFunctions.uuid(),
            egn: "8508010133",
            firstName: "Иван",
            lastName: "",
            personTypeId: "10000500000000000015",
            skipEgnValidation: false
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personDetailsPOST(personDetailsRequestModelEmptylastName, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Поле фамилия е задължително.');
        expect(responseAsJson['isSuccess']).toBe(false);
    });

    test('200 при празно egn', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personDetailsRequestModelEmptyegn: PersonDetailsRequestModel = {
            operation: "save",
            processId: stringFunctions.uuid(),
            egn: "",
            firstName: "Иван",
            middleName: "Иванов",
            lastName: "Иванов",
            personTypeId: "10000500000000000015",
            isPhysicalPerson: true,
            skipEgnValidation: false
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personDetailsPOST(personDetailsRequestModelEmptyegn, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Въведете ЕГН или ЛНЧ.');
        expect(responseAsJson['isSuccess']).toBe(false);
    });
});
