import { test, expect } from '@playwright/test';
import { PropertyRegsiterApi } from '../../propertyRegisterApi';
import StringFunctions from '../../functions/string_functions';
import PersonSearchRequestModel from '../../requestModels/personSearchRequestModel';

test.describe('PersonSearch API tests', () => {
    const propertyRegisterApi = new PropertyRegsiterApi();
    const stringFunctions = new StringFunctions();

    test('200 с грешка при неподадено егн за ФЛ', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personSearchRequestModelEmptyEgn: PersonSearchRequestModel = {
            siteId: "001",
            operation: "physicalPerson",
            processId: stringFunctions.uuid(),
            egn: '',
            isExtendedSearch: true,
            isPhysicalPersonSearch: true,
            isLegalEntitySearch: true,
            searchOnlyExternal: true,
            searchOptionValue: "physicalPerson"
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personSearchPOST(personSearchRequestModelEmptyEgn, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Задали сте недостатъчен брой критерии за търсене');
        expect(responseAsJson['isSuccess']).toBe(false);
    });

    test('200 с грешка при неподадено егн за ЧФЛ', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personSearchRequestModelEmptyEgnFNP: PersonSearchRequestModel = {
            operation: "foreignPerson",
            processId: stringFunctions.uuid(),
            personalNumber: "",
            isPhysicalPersonSearch: true,
            searchOptionValue: "foreignPerson"
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personSearchPOST(personSearchRequestModelEmptyEgnFNP, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Задали сте недостатъчен брой критерии за търсене');
        expect(responseAsJson['isSuccess']).toBe(false);
    });

    test('200 с грешка при неподадено егн за ЧЮЛ', async ({ request }) => {
        // Подготвяме данни с невалидна операция
        const personSearchRequestModelEmptyEgnFLP: PersonSearchRequestModel = {
            operation: "foreignPerson",
            processId: stringFunctions.uuid(),
            personalNumber: "",
            isLegalEntitySearch: true,
            searchOptionValue: "foreignPerson"
        }

        //Act: изпълняване POST заявак към АПИ-то
        const response = await propertyRegisterApi.personSearchPOST(personSearchRequestModelEmptyEgnFLP, request);

        //Assert: проверяване очаквания резултат
        expect(response.status()).toBe(200);

        const responseAsJson = await response.json();
        expect(responseAsJson['errors'][0]['error']).toEqual('Задали сте недостатъчен брой критерии за търсене');
        expect(responseAsJson['isSuccess']).toBe(false);
    });
});
