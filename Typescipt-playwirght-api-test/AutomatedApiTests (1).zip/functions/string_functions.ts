import { v4 as uuid4 } from 'uuid'

/**
 * Помощни функции за string.
 */
export default class StringFunctions {

    /**
     * Генерира низ от символи с определна дължина.
     * @param length дължина на низ-а.
     * @returns низ с от символи с определена дължина.
     */
    makeString(length: number) {
        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const charactersLength = characters.length;
        let counter = 0;
        while (counter < length) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
            counter += 1;
        }
        return result;
    }

    /**
     * Генерира guid.
     * @returns guid.
     */
    uuid() {
        return uuid4();
    }
}