import { SecretClient } from "@azure/keyvault-secrets";
import { DefaultAzureCredential } from "@azure/identity";

export const apiTokenFromKeyVault = (async () => {
    try {
        const keyVaultApiTokenKey: string = process.env["KEY_VAULT_API_TOKEN_KEY"] || '';
        const keyVaultUrl: string = process.env["KEY_VAULT_NAME"] || '';
        const credential = new DefaultAzureCredential();
        const client = new SecretClient(keyVaultUrl, credential);

        // Replace 'your-secret-name' with the name of your secret
        const secret = await client.getSecret(keyVaultApiTokenKey);
        return secret.value;
    } catch (error) {
        return null;
    }
});