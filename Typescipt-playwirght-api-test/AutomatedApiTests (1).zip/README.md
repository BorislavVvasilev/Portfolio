# Автоматизирани API тестове

## Обща информация
Целта на API тестовете е като минимум да се покрият "негативните" сценарии за всеки един API метод. Тест проекта използва Playwright с TypeScript и  Visual Studio Code, като среда за разработка.

## Необходим софтуер и инструменти 
За нуждите на тестовете е необходимо да се инсталирата следните добавки:
1. VSCode (https://code.visualstudio.com/)
2. Node.js (https://nodejs.org/en)
3. Playwright (https://playwright.dev/docs/intro)
4. Git for Windows (https://git-scm.com/downloads)
5. Azure CLI (https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli)

## Инсталация

1. Отивате на посочения линк на VSCode и изтегляте и инсталирате пакета за Windows 10, 11 x 64
2. Отивате на посочения линк на Node.js и изтегляте и инсталирате пакета за Windows 64-bit
3. Отивате на посочения линк на Playwright documentation и следвате стъпките за инсталация
4. Отивате на посочения линк на Git и изтегляте и инсталирате пакета Git for windows 64-bit версия (уверете се, че е избран Git Credential Manager при опциите за инсталация)
5. Отивате на посочения линк на Azure CLI и изтегляте и инсталирате пакета "Latest release of the Azure CLI (64-bit)"
6. Клониране на проекта от Azure DevOps
   - Отворете проекта и отидете до неговото Git repo
   - Натиснете бутона Clone и копирайте HTTPS линка 
   - Отворете Visual Studio Code и от меню бутоните отляво изберете Source Control 
   - Натиснете бутона Clone Repository
   - Пейстнете копирания линкa и изберете, къде да се свали проекта на файловата система (напр. C:\Users\USERNAME\source\repos)
Ако на някоя от горните стъпки ви поиска акаунт за достъп, се логвате със същия, с който достъпвате Azure DevOps.
7. Инсталиране на всички npm пакети в проекта
   - В отвореното Visual Studio Code стартирайте Terminal -> New Terminal. 
   - В терминала изпълнете следната команда: ```npm install```
   - ако не разпознава командата и казва, че липсва Nodejs, рестaртирайте VSC
   - инсталирате extention-a "Playwright Test for VS Code"

## Стартиране на тестовете
Като предварителна еднократна стъпка във Visual Studio Code Terminal - трябва да изпълните еднократно команда ```az login``` и в browser-a който ви се отвори, да се логнете с акаунта, с който достъпвате Azure DevOps.
1. Всички тестове - в отворения Visual Studio Code Terminal, чрез команда ```npx playwright test```
2. Конретен тест от файл с множество тестове - след test(описанието на теста) се изписва "only": ```test.only('Моя тест')``` тази команда пуска само избрания тест