export interface LastWillDetailsRequestModel {
    id?: string;
    updateCount?: number;
    applicantId?: string;
    actTypeId?: string;
    bookTypeId?: string;
    statusId?: string;
    siteId?: string;
    applicantTypeId?: string;
    lawAreaId?: string;
    registerNumber?: string;
    bringerId?: string;
    volume?: string;
    page?: number;
    judgeId?: string;
    remark?: string;
    registrationDate?: Date;
    registryOfficerId?: string;
    entryTypeId?: string;
    taxValue?: string;
    taxCurrencyId?: string;
    notaryAct?: boolean;
    notaryActNumber?: string;
    notaryActVolume?: string;
    notaryActRegnumber?: string;
    notaryActCase?: string;
    notaryActYear?: string;
    courtAct?: boolean;
    courtActType?: string;
    courtActNumber?: string;
    courtActCourtId?: string;
    courtActYear?: string;
    otherAct?: boolean;
    otherActType?: string;
    otherActNumber?: string;
    otherActDate?: Date;
    otherActIssuer?: string;
    posCode?: string;
    awAreaId?: string;
    legatorId?: string;
    isOldActEntry?: boolean;
    relatedActs?: [
      {
        lastWillId?: string;
        fullDescription?: string;
        actType?: string;
        relationTypeId?: string
      }
    ];
    operation?: string;
    operationParams?: {
      additionalProp1?: string;
      additionalProp2?: string;
      additionalProp3?: string
    };
    processId?: string;
    attachments?: [
      {
        attachmentId?: string;
        createDateAsString?: string;
        fileName?: string;
        fileTypeIdName?: string;
        fileTypeId?: string;
        fileTypeDescription?: string
      }
    ]
  }