export interface LastWillRegisterRequestModel {

        actTypeId?: string;
        canCreateOrCopy?: boolean;
        errors?: Error[];
        filterApplicantString?: string;
        isSuccess?: boolean;
        operation?: string;
        processId?: string;
        registerNumber?: string;
        registrationDate?: string;
        resultData?: any[];
        siteId?: string;
        statusId?: string;
        taxStatusId?: string;
    }

    
