export default interface PersonSearchRequestModel {
    processId?: string,
    egn?: string,
    personalNumber?: string,
    foreignLotNumber?: string,
    personalLotNumber?: string,
    firstName?: string,
    middleName?: string,
    lastName?: string,
    nationalityId?: string,
    dateOfBirth?: Date,
    passportNumber?: string
    placeOfBirth?: string,
    countryId?: string,
    isExtendedSearch?: true,
    isPhysicalPersonSearch?: true,
    isLegalEntitySearch?: true,
    excludeExternal?: true,
    searchOnlyExternal?: true,
    siteId?: string,
    operation?: string,
    searchOptionValue?: string
}