export interface LastWillReportRegisterModel 
{
    searchByNumber?: boolean;
    year?: number;
    fromNumber?: number;
    toNumber?: number;
    fromDate?: string;
    toDate?: string;
    bookTypeId?: string;
    statusId?: string;
    showSummary?: boolean;
    siteNomId?: string;
    operation?: string;
    hasAccess?: boolean;
    isSuccess?: boolean;
    reportParameterKey?: string;
}
