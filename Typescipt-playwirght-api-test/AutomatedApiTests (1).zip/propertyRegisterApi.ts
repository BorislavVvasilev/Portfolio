import { APIRequestContext } from '@playwright/test';
import { LastWillDetailsRequestModel } from './requestModels/lastWillDetailsRequestModel';
import { LastWillSearchRelatedRequestModel } from './requestModels/lastWillSearchRelatedRequestModel';
import { PersonDetailsRequestModel } from './requestModels/personDetailsRequestModel';
import PersonSearchRequestModel from './requestModels/personSearchRequestModel';
import { LastWillReportRegisterModel } from './requestModels/lastWillReportRegisterModel';
import {LastWillRegisterRequestModel} from './requestModels/lastWillRegisterRequestModel';

const lastWillDetailsEndpointUrl = '/api/LastWillDetails/LastWillDetails';
const lastWillSearchRelatedEndpointUrl = '/api/LastWillSearchRelated/LastWillSearchRelated';
const personDetailsEndpointUrl = '/api/PersonDetails/PersonDetails';
const personSearchEndpointUrl = '/api/PersonSearch/Search';
const lastWillReportRegisterURL = '/api/LastWillRegister/LastWillReportRegister';
const lastWillRegisterURL = '/api/LastWillRegister/LastWillRegister';

export class PropertyRegsiterApi {

    async lastWillRegisterPOST(lastWillRegisterData: LastWillRegisterRequestModel, request: APIRequestContext) {
        return await request.post(lastWillRegisterURL, {
            data: lastWillRegisterData
        });
    }
    async lastWillReportRegisterPOST(lastWillReportRegisterData: LastWillReportRegisterModel, request: APIRequestContext) {
        return await request.post(lastWillReportRegisterURL, {
            data: lastWillReportRegisterData
        });
    }
    
    async lastWillDetailsPOST(lastWillDetailsRequestData: LastWillDetailsRequestModel, request: APIRequestContext) {
        return await request.post(lastWillDetailsEndpointUrl, {
            data: lastWillDetailsRequestData
        });
    }

    async lastWillSearchRelatedPOST(lastWillSearchRelatedData: LastWillSearchRelatedRequestModel, request: APIRequestContext) {
        return await request.post(lastWillSearchRelatedEndpointUrl, {
            data: lastWillSearchRelatedData
        });
    }

    async personDetailsPOST(personDetailsData: PersonDetailsRequestModel, request: APIRequestContext) {
        return request.post(personDetailsEndpointUrl, {
            data: personDetailsData
        });
    }
    async personSearchPOST(personSearchData: PersonSearchRequestModel, request: APIRequestContext) {
        return request.post(personSearchEndpointUrl, {
            data: personSearchData
        });
    }
}


