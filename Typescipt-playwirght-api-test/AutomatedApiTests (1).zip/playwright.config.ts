import { defineConfig } from '@playwright/test';
import dotenv from 'dotenv';
import { apiTokenFromKeyVault } from './utils/azureConfig';

dotenv.config();

async function getConfig() {
  // по  подразбиране взимаме тестов Token от env променлива
  let token = process.env.API_TOKEN || '';

  // в среда за разработка използваме Token от KeyVault
  if (process.env.IS_DEVELOPMENT === '1') {
    token = (await apiTokenFromKeyVault()) || '';  }

  // връщаме дефиниция на конфигурация, която ще се използва от всички тестове
  return defineConfig({
    use: {
      baseURL: 'https://iiscpr-vnext.crossroad.ltd:5002',
      ignoreHTTPSErrors: true,
      extraHTTPHeaders: {
        'Accept': 'text/plain',
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
    }
  });
}

export default getConfig();